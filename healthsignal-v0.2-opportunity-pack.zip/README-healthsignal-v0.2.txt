HealthSignal v0.2 opportunity dataset

Use healthsignal-opportunities-v0.2.json in the prototype /data folder.

Prototype behavior:
- Today = top 5-10 by rank_hint/personalized rank
- Explore = ALL opportunities, including long-tail
- Full brief should be clickable/readable
- Evidence items should be clickable
- Save -> Saved and Watch -> Watching should persist visually
- Show Jurisdiction, Sector, Signal Type, Expansion potential, Risk
- Details & Evidence should separate primary evidence, news, and supporting/historical evidence

This is test data, not a production export.
